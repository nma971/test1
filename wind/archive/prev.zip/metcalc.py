"""
Created on Sun May 23 00:35:38 2021

@author: mathew

"""
import xarray as xr
import metpy.calc as mpcalc
from metpy.units import units 

def read_data(ncfile,time):
    data = xr.open_dataset(ncfile)
    wd,ws = data["wd10"],data["ws10"]
    dire,spee = wd[time,0,:,:],ws[time,0,:,:]
    return dire,spee
    
def components(direction,speed):
    u,v = mpcalc.wind_components(speed*units('m/s'),direction*units.deg)
    return u,v


