"""
Created on Sun May 23 00:54:43 2021

@author: mathew

"""

import numpy as np
from PIL import Image
import json

def img_gen(u,v):
    uvals,vvals = u.values, v.values
    u_arr = np.round(255*((uvals - np.min(uvals))/(np.max(uvals) - np.min(uvals)))).astype(int)
    v_arr = np.round(255*((vvals - np.min(vvals))/(np.max(vvals) - np.min(vvals)))).astype(int)
    e_arr = np.zeros(v_arr.shape)
    m_arr = e_arr+255
    r = Image.fromarray(u_arr.astype(np.uint8))
    g = Image.fromarray(v_arr.astype(np.uint8))
    b = Image.fromarray(e_arr.astype(np.uint8))
    a = Image.fromarray(m_arr.astype(np.uint8))
    res = Image.merge('RGBA',(r,g,b,a))
    res = res.rotate(180)
    res = res.transpose(Image.FLIP_LEFT_RIGHT)    
    return res

def write_attr(u,v):
    width,height = u.values.shape[1],v.values.shape[0]
    u_min,v_min = int(np.min(u.values)),int(np.min(v.values))
    u_max,v_max = int(np.max(u.values)),int(np.max(v.values))
    desc = {'source':"WRF MOSDAT model forecast",
            "date":str(u.time.values)[:14],
            "width":str(width),
            "height":str(height),
            "uMin":u_min,
            "uMax":u_max,
            "vMin":v_min,
            "vMax":v_max}
    jstr = json.dumps(desc,indent = 4)
    return jstr
    
