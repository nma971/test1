"""
Created on Sun May 23 00:35:23 2021

@author: mathew

"""

import glob
from image import img_gen,write_attr
from metcalc import read_data,components
import json

nc = glob.glob("/home/mathew/hdd/UBU20/hdd/weather/scripts_test/SAC_WRF/*.nc")
out_dir = "/home/mathew/hdd/UBU20/hdd/weather/windmap/webgl-wind/demo/wind/"


wd,ws = read_data(nc[2],0)

u,v = components(wd, ws)

img = img_gen(u,v)

attr = write_attr(u, v)

with open("data.json",'w') as out:
    out.write(attr)






